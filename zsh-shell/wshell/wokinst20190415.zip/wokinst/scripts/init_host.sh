#!/bin/sh
# File    :   init_host.sh
# Time    :   2019/04/10 13:08:18
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

Init_Host(){
# Close SELINUX
setenforce 0
sed -i 's/^SELINUX=.*$/SELINUX=disabled/' /etc/selinux/config

# Close firewalld
systemctl stop firewalld.service
systemctl disable firewalld.service

# Set timezone
rm -rf /etc/localtime
ln -s /usr/share/zoneinfo/${timezone} /etc/localtime
#ln -s /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
# Update time
# ntpdate -u pool.ntp.org
# [ ! -e "/var/spool/cron/root" -o -z "$(grep 'ntpdate' /var/spool/cron/root)" ] && { echo "*/20 * * * * $(which ntpdate) -u pool.ntp.org > /dev/null 2>&1" >> /var/spool/cron/root;chmod 600 /var/spool/cron/root; }
}
