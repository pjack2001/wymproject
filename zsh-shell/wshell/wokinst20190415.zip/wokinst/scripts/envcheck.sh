#!/bin/sh
# File    :   envcheck.sh
# Time    :   2019/04/12 10:20:13
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

# ----------------环境监测
osver=$(cat /etc/redhat-release)
JAVA_VERSION=`java -version 2>&1 |awk 'NR==1{ gsub(/"/,""); print $3 }'`
PYTHON_VERSION=`python -V 2>&1`
ANSIBLE_VERSION=`ansible --version 2>&1 |head -n 1`
Docker_VERSION=`docker -v 2>&1 |cut -d "," -f 1|awk '{print $1 ',' $3}'`
MYSQL_VERSION=`mysql -V 2>&1 |cut -d "," -f 1|awk '{print $1 $5}'`
Nginx_VERSION=`/usr/local/nginx/sbin/nginx -V 2>&1 |awk 'NR==1{ print $3 }'`
Keepalived_VERSION=`/usr/local/keepalived/sbin/keepalived -v 2>&1|awk 'NR==1{ print $1 $2 }'`
#_VERSION=``

Check_Dir(){
 echo -e "basepath目录："$basepath
 echo -e "prepath目录："$prepath
 echo -e "pprepath目录："$pprepath
 echo -e "rpmdir目录："$rpmdir
 echo -e "rpv目录："$rpv
 echo -e "srcdir目录："$srcdir
 echo -e "scriptsdir目录："$scriptsdir
 echo -e "logsdir目录："$logsdir
}

function EnvCheck()
{
    echo "--> 开始执行系统环境检测"
    echo "=========================================================================="
    echo "            检测项                输出值                    合格  "
    echo "=========================================================================="
    echo -e " (1): \033[34m操作系统版本：\033[0m "$osver
    echo -e " (2): \033[34mPYTHON版本：     \033[0m "$PYTHON_VERSION
    echo -e " (3): \033[34mANSIBLE版本：     \033[0m "$ANSIBLE_VERSION
    echo -e " (4): \033[34mDocker版本：     \033[0m "$Docker_VERSION
    echo -e " (5): \033[34mMysql版本：     \033[0m "$MYSQL_VERSION
    echo -e " (6): \033[34mJDK版本：     \033[0m "$JAVA_VERSION
    echo -e " (7): \033[34mNginx版本：     \033[0m "$Nginx_VERSION
    echo -e " (8): \033[34mKeepalived版本：     \033[0m "$Keepalived_VERSION
    # echo "---------如何所有环境检测项都满足，可以正常安装-----------"
    echo "=========================================================================="
    echo ""
    echo ""
    echo ""

#/usr/local/keepalived/sbin/keepalived -v

    # # 检查操作系统是否符合最低要求
    # if [ "${CentOS_ver}" -ne '7' ]; then 
    # {
    #     echo "${CWARNING}操作系统条件不满足，请使用Centos7系统。 ${CEND}"; 
    #     return 1;
    # }
    # fi

    # # Check if user is root
    # [ $(id -u) != "0" ] && { 
    #     echo "${CFAILURE}Error: 必须使用root用户执行安装程序！${CEND}";
    #     return 1; 
    # }

    return 0;
}
