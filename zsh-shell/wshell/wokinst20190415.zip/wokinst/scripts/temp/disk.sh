#!/bin/bash
#########################################################################
# File Name: 007.sh
# Author: LookBack
# Email: taoxiaoyuzy@vip.qq.com
# Licence: GNU General Public Licence
# Created Time: Wed 23 Jul 2014 04:11:57 AM CST
#########################################################################

mntboot="/mnt/boot"
mntsysroot="/mnt/sysroot"
Program="bash ifconfig ls df ping"

checkInput() {
	clear
	until [ -n "$(fdisk -l $DiskName)" -a -z "$(echo ${DiskName} | grep -o '[0-9]')" ]; do
		read -p "Plz Enter A Device File Name : " DiskName
	done
}

printDisk() {
	clear
	fdisk -l $DiskName
	cat << EOF
=============================================================================================
====                                                                                     ====
==== Subsequent actions will damage all the files on the device, ask whether to continue ====
==== If you continue, please enter: y|Y|Yes|YES|yes|yES|yEs|YeS|yeS                      ====
==== If you do not want to enter the: n|N|No|NO|no|nO                                    ====
====                                                                                     ====
=============================================================================================
EOF
	read -p "Plz input : " XDisk
	clear
}


umountDisk() {
	[ -n "$(mount | grep -oE "$1")" ] && umount $1 &> /dev/null
}

makePartition() {
	for i in 1 2; do umountDisk ${DiskName}$i;done
	dd if=/dev/zero of=$DiskName bs=512 count=1 &> /dev/null
	fdisk $DiskName &> /dev/null << EOF
n
p
1

+50M
n
p
2

+512M
w
EOF
}

mke2fsPartition() {
	mke2fs -t $1 $2 &> /dev/null
}

mountPartition() {
	[ ! -d "$mntboot" ] && mkdir -p $mntboot
	[ ! -d "$mntsysroot" ] && mkdir -p $mntsysroot
	mount $1 $2
}

installGrub() {
	grub-install --root-directory=/mnt $DiskName &> /dev/null
	cp /boot/vmlinuz-$(uname -r) $mntboot/
	#cp /boot/initramfs-$(uname -r).img $mntboot/
	dracut $mntboot/initramfs-$(uname -r).img  $(uname -r)
	cat > $mntboot/grub/grub.conf << EOF
default=0
timeout=5
splashp_w_picpath=(hd0,0)/grub/splash.xpm.gz
hiddenmenu
#password --md5 \$1\$6Gi8p1\$U1hyuGTVQnsvz5gG9w9pf/
title CentOS $(uname -r) -This is a TEST OS-
	root (hd0,0)
	kernel /vmlinuz-$(uname -r) ro root=/dev/sda2 selinux=0 init=/bin/bash
	initrd /initramfs-$(uname -r).img
EOF
	chmod 600 $mntboot/grub/grub.conf
}

makeFHSdir() {
	mkdir -p $mntsysroot/{bin,dev,etc,home,lib/modules,lib64,opt,proc,root,sbin,selinux,sys,usr/{bin,sbin,lib,lib64},mnt,media,tmp,var/lib}
}

transplantProgram() {
	for i in $Program; do
		[ ! -d ${mntsysroot}$(dirname $(which --skip-alias $i)) ] && mkdir -p ${mntsysroot}$(dirname $(which --skip-alias $i))
		[ ! -f ${mntsysroot}$(which --skip-alias $i) ] && cp $(which --skip-alias $i) ${mntsysroot}$(dirname $(which --skip-alias $i))/
		for j in $(ldd $(which --skip-alias $i) | grep -oE '/[^[:space:]]+'); do
			[ ! -d ${mntsysroot}$(dirname $j) ] && mkdir -p ${mntsysroot}$(dirname $j)
			[ ! -f ${mntsysroot}$j ] && cp $II ${mntsysroot}$j
		done
	done
}

nextScript() {
	printDisk
	case $XDisk in
	y|Y|[yY][eE][sS])
		makePartition
		for i in 1 2;do mke2fsPartition ext4 ${DiskName}$i;done
		mountPartition ${DiskName}1 $mntboot
		mountPartition ${DiskName}2 $mntsysroot
		installGrub
		makeFHSdir
		transplantProgram
		seq 3 | xargs -i sync
		clear
		;;
	n|N|[nN][oO])
		clear
		exit 0
		;;
	*)
		nextScript
	esac
}

main() {
	clear
	read -p "Plz Enter A Device File Name : " DiskName
	case $DiskName in
	q|Q|[qQ][uU][iI][tT])
		clear
		exit 0
		;;
	*)
		checkInput
		nextScript
	esac
}

main