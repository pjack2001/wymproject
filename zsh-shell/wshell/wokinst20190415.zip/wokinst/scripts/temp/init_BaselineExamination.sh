#!/bin/bash
#version v1.0 by pensar
#操作系统linux 配置规范--centos7

cat <<EOF
***************************************************************
 linux安全配置检查脚本:
    1. 输出结果在/tmp/check/目录下查看
    2.检查范围及检查项(共计4大类，33项)
*日志审计配置*：
    [1]检查Cron任务授权
    [2]检查是否对syslog登录事件记录
    [3]检查是否对rsyslog.conf配置审核
    [4]检查系统日志读写权限
    [5]检查是否对远程日志服务器配置    
*系统文件管理*：
    [1]检查是否对登录超时时间配置
    [2]检查系统磁盘状态
    [3]检查是否禁止匿名FTP访问
    [4]检查是否修改FTP banner 信息
    [5]检查是否关闭不必要的服务
    [6]检查系统core dump状态
    [7]检查系统补丁    
*用户账号配置*：
    [1]检查是否存在无用账号
    [2]检查不同用户是否共享账号
    [3]检查是否删除或锁定无用账号
    [4]检查是否存在无用用户组
    [5]检查是否指定用户组成员使用su命令
    [6]检查密码长度及复杂度策略
    [7]检查是否对用户远程登录进行限制
    [8]检查是否配置加密协议
    [9]检查是否配置密码的生存期
    [10]检查用户缺省访问权限
    [11]检查passwd group文件安全权限
    [12]检查是否存在除root之外UID为0的用户
    [13]检查是否配置环境变量
    [14]检查是否对远程连接的安全性进行配置
    [15]检查是否对用户的umask进行配置
    [16]检查是否对重要目录和文件的权限进行设置
    [17]检查是否存在未授权的suid/sgid文件
    [18]检查是否存在异常隐含文件    
*网络通信配置*：
    [1]检查是否对基本网络服务进行配置
    [2]检查是否开启NFS服务
    [3]检查常规网络服务是否运行正常
***************************************************************
EOF
#mkdir /tmp/check
checkdir=/tmp/check
[ ! -d ${checkdir} ] && mkdir -p ${checkdir}
str1=`/sbin/ifconfig -a | grep inet | grep -v 127.0.0.1 | grep -v inet6 | awk '{print $2}' | tr -d "addr:" | head -n 1`
str=`date +%Y%m%d%H%M`_"$str1"

echo "----**日志审计配置**----" >> /tmp/check/${str}_out.txt 
echo "[1] 检查Cron任务授权" >> /tmp/check/${str}_out.txt 
if [ -e /etc/cron.deny ] && [ -e /etc/at.deny ];then
    CRON_DENY=`ls -l /etc/cron.deny | awk '{print $1}'`
    AT_DENY=`ls -l /etc/at.deny | awk '{print $1}'`
    echo "/etc/cron.deny文件授权情况为：${CRON_DENY:1:9}" >> /tmp/check/${str}_out.txt 
    echo "/etc/at.deny文件授权情况为：${AT_DENY:1:9}" >> /tmp/check/${str}_out.txt 
    echo "{'Check_point':'检查Cron任务授权','Check_result':{'/etc/cron.deny文件授权情况为':'${CRON_DENY:1:9}','/etc/at.deny文件授权情况为':'${AT_DENY:1:9}'}}" >> /tmp/check/${str}_dict.txt 
    CRON=`cat /etc/rsyslog.conf | grep "cron.\*"`
    echo "/etc/rsyslog.conf的配置情况为：${CRON}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到/etc/cron.deny和/etc/at.deny配置文件" >> /tmp/check/${str}_out.txt 
fi

echo "----------------------------" >> /tmp/check/${str}_out.txt 
echo "[2]检查是否对syslog登录事件记录" >> /tmp/check/${str}_out.txt 
if [ -e /etc/syslog.conf ];then
    Clog=`cat /etc/syslog.conf | grep /var/log/secure | grep -E "authpriv\.\*"`
    echo "/etc/syslog.conf的配置为：${Clog}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到/etc/syslog.conf配置文件" >> /tmp/check/${str}_out.txt 
fi

echo "----------------------------" >> /tmp/check/${str}_out.txt 
echo "[3]检查是否对rsyslog.conf配置审核" >> /tmp/check/${str}_out.txt 
if [ -e /etc/rsyslog.conf ];then
    LOG=`cat /etc/rsyslog.conf | grep @loghost` 
    echo "rsyslog.conf文件的配置为${LOG}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到/etc/rsyslog.conf配置文件" >> /tmp/check/${str}_out.txt 
fi

echo "----------------------------" >> /tmp/check/${str}_out.txt 
echo "[4]检查系统日志读写权限" >> /tmp/check/${str}_out.txt 
if [ -e /var/log/messages ];then
    MESSAGES=`ls -l /var/log/messages | awk '{print $1}'`
    echo "/var/log/messages的文件权限为：${MESSAGES:1:9}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到/var/log/messages的文件" >> /tmp/check/${str}_out.txt 
fi
if [ -e /var/log/secure ];then
    SECURE=`ls -l /var/log/secure | awk '{print $1}'`
    echo "/var/log/secure 的文件权限为：${SECURE:1:9}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到/var/log/secure的文件" >> /tmp/check/${str}_out.txt 
fi

if [ -e /var/log/maillog ];then
    MAILLOG=`ls -l /var/log/maillog | awk '{print $1}'`
    echo "/var/log/maillog 的文件权限为：${MAILLOG:1:9}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到/var/log/maillog的文件" >> /tmp/check/${str}_out.txt 
fi

if [ -e /var/log/cron ];then
    CRON=`ls -l /var/log/cron | awk '{print $1}'`
    echo "/var/log/cron 的文件权限为：${CRON:1:9}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到/var/log/cron的文件" >> /tmp/check/${str}_out.txt 
fi
if [ -e /var/log/spooler ];then
    SPOOLER=`ls -l /var/log/spooler | awk '{print $1}'`
    echo "/var/log/spooler 的文件权限为：${SPOOLER:1:9}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到/var/log/spooler的文件" >> /tmp/check/${str}_out.txt 
fi

if [ -e /var/log/boot/log ];then
    LOG=`ls -l /var/log/boot/log | awk '{print $1}'`
    echo "/var/log/boot/log 的文件权限为：${LOG:1:9}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到/var/log/boot/log的文件" >> /tmp/check/${str}_out.txt 
fi

echo "----------------------------" >> /tmp/check/${str}_out.txt 
echo "[5]检查是否对远程日志服务器配置" >> /tmp/check/${str}_out.txt 
if [ -e /etc/rsyslog.conf ];then
    RSYS=`cat /etc/rsyslog.conf | grep "@${str1}" | grep $'\t' | grep \.\*` 
    echo "远程日志服务器配置情况为：${RSYS}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到/etc/rsyslog.conf配置文件" >> /tmp/check/${str}_out.txt 
fi
echo "----------------------------" >> /tmp/check/${str}_out.txt
echo ""
echo "----**系统文件管理**----" >> /tmp/check/${str}_out.txt 
echo "[1]检查是否对登录超时时间配置" >> /tmp/check/${str}_out.txt 
if [ -e /etc/profile ] && [ -e /etc/bashrc ]; then
    TMOUT=`cat /etc/profile | grep HISTTIMEFORMAT | grep TMOUT`
    if [ -n ${TMOUT} ]; then
        echo "/etc/profile的超时时间设置情况为：${TMOUT}" >> /tmp/check/${str}_out.txt 
        FORMAT=`cat /etc/bashrc | grep export | grep HISTTIMEFORMAT`
        if [ -n ${FORMAT} ];then
            echo "/etc/bashrc的设置为${FORMAT}" >> /tmp/check/${str}_out.txt 
        else
            echo "/etc/bashrc不存在对应配置" >> /tmp/check/${str}_out.txt 
        fi
    else
        echo "/etc/profile文件不存在对应配置" >> /tmp/check/${str}_out.txt 
    fi
else
    echo "不存在/etc/profile文件以及/etc/bashrc文件" >> /tmp/check/${str}_out.txt 
fi


echo "----------------------------" >> /tmp/check/${str}_out.txt 
echo "[2]检查系统磁盘状态" >> /tmp/check/${str}_out.txt 
DF=`df -h | awk 'NR!=1{print $5}' | awk -F[\%] '{print $1}'`
for i in $DF
do
    if [ $i -ge 80 ];then
        flag=1
    else
        flag=0
    fi
done
if [ $flag = 1 ];then
    echo "系统磁盘使用率大于80%" >> /tmp/check/${str}_out.txt 
else [ $flag = 0 ]
    echo "系统磁盘状态小于80%" >> /tmp/check/${str}_out.txt 
fi    
    
echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[3]检查是否禁止匿名FTP访问" >> /tmp/check/${str}_out.txt 
if [ -e /etc/vsftpd.conf ];then
    cat /etc/vsftpd.conf | grep "anonymous_enable=NO" 
    if [ $? -eq 0 ]; then
        echo "/etc/vsftpd.conf文件有设置：anonymous_enable=NO" >> /tmp/check/${str}_out.txt 
    else
        echo "不符合规范，需编辑/etc/vsftpd.conf文件，设置：anonymous_enable=NO" >> /tmp/check/${str}_out.txt 
    fi
else
    echo "未找到/etc/vsftpd.conf文件" >> /tmp/check/${str}_out.txt 
fi

echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[4]检查是否修改FTP banner 信息" >> /tmp/check/${str}_out.txt 
if [ -e /etc/vsftpd.d/vsftpd.conf ];then
    BANNER=`cat /etc/vsftpd.d/vsftpd.conf | grep ftpd_banner | grep -F[=] awk '{print $1}'`
    if [ -n ${BANNER} ];then
        echo "banner信息为${BANNER}" >> /tmp/check/${str}_out.txt 
    else
        echo "未设置banner信息" >> /tmp/check/${str}_out.txt 
    fi
else
    echo "未找到/etc/vsftpd.d/vsftpd.conf文件" >> /tmp/check/${str}_out.txt 
fi

if [ -e /etc/ftpaccess ];then
    cat /etc/ftpaccess | grep "banner /path/to/ftpbanner"
    if [ -e -eq 0 ];then
        echo "/etc/ftpaccess文件中已经设置banner路径" >> /tmp/check/${str}_out.txt 
    else
        echo "/etc/ftpaccess文件中未设置banner路径" >> /tmp/check/${str}_out.txt 
    fi
else
    echo "不存在/etc/ftpaccess文件" >> /tmp/check/${str}_out.txt 
fi

echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[5]检查是否关闭不必要的服务" >> /tmp/check/${str}_out.txt 
SERVICE=`ps -ef`
echo "系统服务情况为${SERVICE}" >> /tmp/check/${str}_out.txt 
SER_LIST=`systemctl list-units -all --type=service`
echo "服务有${SER_LIST}" >> /tmp/check/${str}_out.txt 
if [ -e /etc/xinetd.conf ];then
    echo "在/etc/xinetd.conf文件中禁止不必要的基本网络服务" >> /tmp/check/${str}_out.txt 
else
    echo "未找到/etc/xinetd.conf文件" >> /tmp/check/${str}_out.txt 
fi


echo "----------------------------" >> /tmp/check/${str}_out.txt 
echo "[6]检查系统core dump状态" >> /tmp/check/${str}_out.txt 
if [ -e /etc/security/limits.conf ];then
    cat /etc/security/limits.conf | grep \* | grep soft | grep core  | grep 0
    if [ $? -eq 0 ];then
        cat /etc/security/limits.conf | grep \* | grep hard | grep core  | grep 0
        if [ $? -eq 0 ];then
            echo "/etc/security/limits.conf符合安全配置" >> /tmp/check/${str}_out.txt 
        else
            echo "/etc/security/limits.conf未安装规范进行设置" >> /tmp/check/${str}_out.txt 
        fi
    else
        echo "/etc/security/limits.conf未安装规范进行设置" >> /tmp/check/${str}_out.txt 
    fi
else
    echo "未找到/etc/security/limits.conf配置文件"  >> /tmp/check/${str}_out.txt 
fi

echo "----------------------------" >> /tmp/check/${str}_out.txt 
echo "[7]检查系统补丁" >> /tmp/check/${str}_out.txt 
OS=`uname -a`
echo "系统版本情况为${OS}" >> /tmp/check/${str}_out.txt 



echo "----**用户账号配置**----" >> /tmp/check/${str}_out.txt 
echo "[1]检查是否存在无用账号" >> /tmp/check/${str}_out.txt 
passwd=`ls -l /etc/passwd | awk '{print $1}'`
if [ "${passwd:1:9}" = "rw-r--r--" ]; then
    echo "/etc/passwd文件权限为644，符合规范" >> /tmp/check/${str}_out.txt 
else
    echo "/etc/passwd文件权限为${passwd:1:9}，不符合规范" >> /tmp/check/${str}_out.txt 
fi
PASSWD_U=`cat /etc/passwd | awk -F[:] '{print $1}'`
echo "查看是否存在无用账号：${PASSWD_U}" >> /tmp/check/${str}_out.txt 

    
echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[2]检查不同用户是否共享账号" >> /tmp/check/${str}_out.txt     
PASS=`cat /etc/passwd | awk -F[:] '{print $1}'`
echo "cat /etc/passwd结果为${PASS}" >> /tmp/check/${str}_out.txt 
#查看所有账号，与管理员确认是否有共享账号    
    
echo "----------------------------" >> /tmp/check/${str}_out.txt 
echo "[3]检查是否删除或锁定无用账号" >> /tmp/check/${str}_out.txt 
NOlogin=`cat /etc/passwd | grep nologin | awk -F[:] '{print $1}'`
echo "shell域中为nologin的账户有${NOlogin}" >> /tmp/check/${str}_out.txt 

    
echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[4]检查是否存在无用用户组" >> /tmp/check/${str}_out.txt 
GROUP=`ls -l /etc/group | awk '{print $1}'`
echo "/etc/group文件权限为${GROUP}" >> /tmp/check/${str}_out.txt 
GROUP_U=`cat /etc/group | awk -F[:] '{print $1}'`
echo "/etc/group用户组有${GROUP}" >> /tmp/check/${str}_out.txt 

    
echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[5]检查是否指定用户组成员使用su命令" >> /tmp/check/${str}_out.txt 
if [ -e /etc/pam.d/su ];then
    SUFFI=`cat /etc/pam.d/su | grep auth | grep sufficient | grep pam_rootok.so`
    REQUIRED=`cat /etc/pam.d/su | grep auth | grep required | grep group=`
    echo "是否指定用户组成员情况为${SUFFI}\n${REQUIRED}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到/etc/pam.d/su配置文件" >> /tmp/check/${str}_out.txt 
fi



echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[6]检查密码长度及复杂度策略" >> /tmp/check/${str}_out.txt 
if [ -e /etc/pam.d/system-auth ];then
    passComplexity=`cat /etc/pam.d/system-auth | grep "pam_pwquality.so"`
    passucredit=`cat /etc/pam.d/system-auth | grep "pam_pwquality.so" | grep -e ucredit | awk '{print $4}'`
    passlcredit=`cat /etc/pam.d/system-auth | grep "pam_pwquality.so" | grep -e lcredit | awk '{print $5}'`
    passdcredit=`cat /etc/pam.d/system-auth | grep "pam_pwquality.so" | grep -e dcredit | awk '{print $6}'`
    passocredit=`cat /etc/pam.d/system-auth | grep "pam_pwquality.so" | grep -e ocredit | awk '{print $7}'`
    echo "密码复杂度策略为：${passComplexity}" >> /tmp/check/${str}_out.txt     
    echo "密码复杂度策略中设置的大写字母个数为：${passucredit}" >> /tmp/check/${str}_out.txt 
    echo "密码复杂度策略中设置的小写字母个数为：${passlcredit}" >> /tmp/check/${str}_out.txt 
    echo "密码复杂度策略中设置的数字个数为：${passdcredit}" >> /tmp/check/${str}_out.txt 
    echo "密码复杂度策略中设置的特殊字符个数为：${passocredit}" >> /tmp/check/${str}_out.txt 
else
    ehco "不存在/etc/pam.d/system-auth文件" >> /tmp/check/${str}_out.txt 
fi
    
echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[7]检查是否对用户远程登录进行限制" >> /tmp/check/${str}_out.txt 
cat /etc/securetty | grep "#" | grep tty
if [ $? -eq 0 ];then
    echo "注释掉所有tty设备" >> /tmp/check/${str}_out.txt 
else
    echo "未注释掉所有tty设备" >> /tmp/check/${str}_out.txt 
fi

RootLogin=`cat /etc/ssh/sshd_config | grep PermitRootLogin | awk '{print $2}'`
if [ "${RootLogin}" == "yes" ];then
    echo "/etc/ssh/sshd_config中PermitRootLogin配置为yes" >> /tmp/check/${str}_out.txt 
else [ "${RootLogin}" == "no" ]
    echo "/etc/ssh/sshd_config中PermitRootLogin配置为no" >> /tmp/check/${str}_out.txt 
fi



echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[8]检查是否配置加密协议" >> /tmp/check/${str}_out.txt 
SSH=`ps -elf | grep ssh`
echo "ssh服务状态为${SSH}"  >> /tmp/check/${str}_out.txt 
if [ -e /etc/ssh/sshd_config ];then
    cat /etc/ssh/sshd_config | grep "Host*" | grep "Protocol 2"
    if [ $? -eq 0 ];then
        echo "/etc/ssh/sshd_config文件符合安全配置" >> /tmp/check/${str}_out.txt 
    else
        echo "/etc/ssh/sshd_config文件中未找到相应配置" >> /tmp/check/${str}_out.txt 
    fi
else
    echo "未找到/etc/ssh/sshd_config文件" >> /tmp/check/${str}_out.txt 
fi    

    
echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[9]检查是否配置密码的生存期" >> /tmp/check/${str}_out.txt 
if [ -e /etc/login.defs ];then
    passmax=`cat /etc/login.defs | grep PASS_MAX_DAYS | grep -v ^# | awk '{print $2}'`
    passmin=`cat /etc/login.defs | grep PASS_MIN_DAYS | grep -v ^# | awk '{print $2}'`
    passlen=`cat /etc/login.defs | grep PASS_MIN_LEN | grep -v ^# | awk '{print $2}'`
    passage=`cat /etc/login.defs | grep PASS_WARN_AGE | grep -v ^# | awk '{print $2}'`
    echo "口令生存周期天数为： ${passmax}" >> /tmp/check/${str}_out.txt 
    echo "口令更改最小时间间隔为天数为：${passmin}" >> /tmp/check/${str}_out.txt 
    echo "口令最小长度天数为：${passlen}" >> /tmp/check/${str}_out.txt 
    echo "口令过期告警时间天数为：${passage}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到/etc/login.defs配置文件" >> /tmp/check/${str}_out.txt 
fi

echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[10]检查用户缺省访问权限" >> /tmp/check/${str}_out.txt 
fileumask=`cat /etc/login.defs | grep -i umask | awk '{print $2}'`
if [ -n $fileumask ]; then    
    echo "/etc/login.defs文件的umask的值为：${fileumask}" >> /tmp/check/${str}_out.txt 
else
    echo "/etc/login.defs文件未配置umask值" >> /tmp/check/${str}_out.txt 
fi


echo "----------------------------" >> /tmp/check/${str}_out.txt 
echo "[11]检查passwd group文件安全权限" >> /tmp/check/${str}_out.txt 

grep ^+: /etc/passwd /etc/shadow /etc/group
if [ $? -eq 0 ];then
    echo "低于安全要求" >> /tmp/check/${str}_out.txt 
else
    echo "符合安全要求" >> /tmp/check/${str}_out.txt 
fi
passwd=`ls -l /etc/passwd | awk '{print $1}'`
echo "/etc/passwd文件权限为${passwd:1:9}" >> /tmp/check/${str}_out.txt 
ETC_group=`ls -l /etc/group | awk '{print $1}'`
echo "/etc/group文件权限为${passwd:1:9}" >> /tmp/check/${str}_out.txt 

igroup=`lsattr /etc/group | grep i`
if [ "$igroup" = "i" ]; then
    echo "/etc/group文件存在i属性文件" >> /tmp/check/${str}_out.txt 
else
    echo "/etc/group文件不存在i文件属性" >> /tmp/check/${str}_out.txt 
fi
ipasswd=`lsattr /etc/passwd | grep i`
if [ "$igshadow" = "i" ]; then
    echo "/etc/passwd存在i属性文件" >> /tmp/check/${str}_out.txt 
else
    echo "/etc/passwd不存在i文件属性" >> /tmp/check/${str}_out.txt 
fi

    
echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[12]检查是否存在除root之外UID为0的用户" >> /tmp/check/${str}_out.txt 
uids=`awk -F[:] 'NR!=1{print $3}' /etc/passwd`  #NR!=1意思的除了第一行不显示。1代表具体的行数
flag=0
for i in $uids
do 
    if [ $i = 0 ]; then
        echo "存在非root账号的账号UID为0，不符合要求" >> /tmp/check/${str}_out.txt 
    else    
        flag=1
    fi
done
if [ $flag = 1 ]; then
   echo "不存在非root账号的UID为0，符合要求" >> /tmp/check/${str}_out.txt 
fi

    
    
echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[13]检查是否配置环境变量" >> /tmp/check/${str}_out.txt 
echo $PATH | egrep '(^|:)(\.|:|$)'
if [ $? -eq 0 ];then
    echo "检查是否包含父目录，低于安全要求" >> /tmp/check/${str}_out.txt 
else
    echo "检查是否包含父目录，符合安全要求" >> /tmp/check/${str}_out.txt 
fi

echo "----------------------------" >> /tmp/check/${str}_out.txt 
echo "[14]检查是否对远程连接的安全性进行配置" >> /tmp/check/${str}_out.txt 
filerhosts=`find / -maxdepth 3 -type f -name .rhosts 2>/dev/null`
if [ -n "$filerhosts" ]; then
    echo "rhosts文件路径为：${filerhosts}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到.rhosts文件" >> /tmp/check/${str}_out.txt 
fi

fileequiv=`find / -maxdepth 2 -name hosts.equiv 2>/dev/null`
if [ -n "$fileequiv" ]; then
    echo "hosts.equiv文件路径为：${fileequiv}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到hosts.equiv文件" >> /tmp/check/${str}_out.txt 
fi
filenetrc=`find / -maxdepth 3 -name .netrc 2>/dev/null`
if [ -n "$filenetrc" ]; then
    echo "netrc文件路径为：${filenetrc}" >> /tmp/check/${str}_out.txt 
else
    echo "未找到.netrc文件" >> /tmp/check/${str}_out.txt 
fi

echo "----------------------------" >> /tmp/check/${str}_out.txt 
echo "[15]检查是否对用户的umask进行配置" >> /tmp/check/${str}_out.txt 
if [ -e /etc/profile ];then
    PROFILE1=`cat /etc/profile | grep -i umask | grep -v '#' | head -n 1 | awk '{print $2}'`
    PROFILE2=`cat /etc/profile | grep -i umask | grep -v '#' | tail -1 | awk '{print $2}'`
    if [ -n "$PROFILE" ]; then
        echo "在/etc/profile文件中umask的值为：${PROFILE}和${PROFILE1}" >> /tmp/check/${str}_out.txt 
    else
        echo "在/etc/profile文件中未找到umask值" >> /tmp/check/${str}_out.txt 
    fi
fi

csh=`cat /etc/csh.login | grep -i umask`
if [ -n "$csh" ]; then
    echo "在/etc/csh.login文件中umask的内容为：${csh}" >> /tmp/check/${str}_out.txt 
else
    echo "在/etc/csh.login文件中未找到umask值" >> /tmp/check/${str}_out.txt 
fi

cshrc1=`cat /etc/csh.cshrc | grep -i umask | grep -v '#' | head -n 1 | awk '{print $2}'`
cshrc2=`cat /etc/csh.cshrc | grep -i umask | grep -v '#' | tail -1 | awk '{print $2}'`
if [ -n "$cshrc" ]; then
    echo "在/etc/csh.cshrc文件中umask的值为：${cshrc1}和${cshrc2}" >> /tmp/check/${str}_out.txt 
else
    echo "在/etc/csh.login文件中未找到umask值" >> /tmp/check/${str}_out.txt 
fi

if [ -e /etc/bashrc ];then
    bashrc1=`cat /etc/bashrc | grep -i umask | grep -v '#' | head -n 1 | awk '{print $2}'`
    bashrc2=`cat /etc/bashrc | grep -i umask | grep -v '#' | tail -1 | awk '{print $2}'`
    if [ -n "$bashrc1" ] && [ -n "$bashrc2" ]; then
        echo "在/etc/bashrc文件中umask内容为：${bashrc1}和${bashrc2}" >> /tmp/check/${str}_out.txt 
    else
        echo "在/etc/bashrc文件中未找到umask值" >> /tmp/check/${str}_out.txt 
    fi
fi

echo "----------------------------" >> /tmp/check/${str}_out.txt 
echo "[16]检查是否对重要目录和文件的权限进行设置" >> /tmp/check/${str}_out.txt 
etc=`ls -l / | grep etc | awk '{print $1}'`
if [ "${etc:1:9}" = "rwxr-x---" ]; then
    echo "/etc/权限为750，符合规范" >> /tmp/check/${str}_out.txt 
else
    echo "/etc/文件权限为${etc:1:9}，不符合规范" >> /tmp/check/${str}_out.txt 
fi

Shadow=`ls -l /etc/shadow | awk '{print $1}'`
if [ "${shadow:1:9}" = "rw-------" ]; then
    echo "/etc/shadow文件权限为600，符合规范" >> /tmp/check/${str}_out.txt 
else
    echo "/etc/shadow文件权限为${Shadow:1:9}，不符合规范" >> /tmp/check/${str}_out.txt 
fi

Passwd=`ls -l /etc | grep passwd | awk '{print $1}'`
if [ "${passwd:1:9}" = "rw-r--r--" ]; then
    echo "/etc/passwd文件权限为644，符合规范" >> /tmp/check/${str}_out.txt 
else
    echo "/etc/passwd文件权限为${Passwd:1:9}，不符合规范" >> /tmp/check/${str}_out.txt 
fi

Group=`ls -l /etc | grep group | awk '{print $1}'`
if [ "${Group:1:9}" = "rw-r--r--" ]; then
    echo "/etc/passwd文件权限为644，符合规范" >> /tmp/check/${str}_out.txt 
else
    echo "/etc/passwd文件权限为${Group:1:9}，不符合规范" >> /tmp/check/${str}_out.txt 
fi


# echo "----------------------------" >> /tmp/check/${str}_out.txt 
# echo "[17]检查是否存在未授权的suid/sgid文件" >> /tmp/check/${str}_out.txt 
# for PART in `grep -v ^# /etc/fstab | awk '($6 != "0") {print "/./"$2 }'`; do
#     RESULT=`find $PART -type f -xdev \( -perm -04000 -o -perm -02000 \) -print`
#         if [ -n $RESULT ];then
#             flag=1
#         else
#             flag=0
#         fi
# done
# if [ $flag -eq 0 ];then
#     echo "返回值为空，符合规范" >> /tmp/check/${str}_out.txt 
# else [ $flag -eq 1 ]
#     echo "返回值不为空，不符合规范" >> /tmp/check/${str}_out.txt 
# fi

echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[18]检查是否存在异常隐含文件" >> /tmp/check/${str}_out.txt 
find  / -name ".. *" -print
HIDDEN=`find  / -name ".. *" -print; find  / -name "...*" -print | cat -v`
if [ -n ${XINETD} ];then
    echo "隐藏文件有${HIDDEN}" >> /tmp/check/${str}_out.txt 
else
    echo "没有隐藏文件" >> /tmp/check/${str}_out.txt 
fi

echo "----**网络通信配置**----" >> /tmp/check/${str}_out.txt 
echo "[1]检查是否对基本网络服务进行配置" >> /tmp/check/${str}_out.txt 
XINETD=`ls  -l  /etc/xinetd.d`
echo "/etc/xinetd.d目录中的包含的基本的网络服务的配置文件为${XINETD}" >> /tmp/check/${str}_out.txt 
    
echo "----------------------------" >> /tmp/check/${str}_out.txt     
echo "[2]检查是否开启NFS服务" >> /tmp/check/${str}_out.txt 
systemctl status nfs
if [ $? -eq 0 ];then
    echo "已开启nfs服务" >> /tmp/check/${str}_out.txt 
else [ $? -eq 3 ]
    echo "未开启nfs服务" >> /tmp/check/${str}_out.txt 
fi

echo "----------------------------" >> /tmp/check/${str}_out.txt 
echo "[3]检查常规网络服务是否运行正常" >> /tmp/check/${str}_out.txt 
#若无telnet命令
telnet localhost 80
if [ $? -eq 0 ];then
    echo "80服务正常运行" >> /tmp/check/${str}_out.txt 
    telnet localhost 25
    if [ $? -eq 0 ];then
        echo "25服务正常运行" >> /tmp/check/${str}_out.txt 
    fi
    telnet localhost 110
    if [ $? -eq 0 ];then
        echo "110服务正常运行" >> /tmp/check/${str}_out.txt 
    fi
    telnet localhost 143
    if [ $? -eq 0 ];then
        echo "143服务正常运行" >> /tmp/check/${str}_out.txt 
    fi
    telnet localhost 443
    if [ $? -eq 0 ];then
        echo "443服务正常运行" >> /tmp/check/${str}_out.txt 
    fi
    telnet localhost 21
    if [ $? -eq 0 ];then
        echo "21服务正常运行" >> /tmp/check/${str}_out.txt 
    fi
else
    echo "系统未安装telnet命令" >> /tmp/check/${str}_out.txt 
fi
