#!/bin/bash
#########################################################################
# File Name: 005.sh
# Author: LookBack
# Email: taoxiaoyuzy@vip.qq.com
# Created Time: Wed 09 Jul 2014 04:06:57 AM CST
#########################################################################

echo=echo
for cmd in echo /bin/echo; do
	$cmd >/dev/null 2>&1 || continue
	if ! $cmd -e "" | grep -qE '^-e'; then
		echo=$cmd
		break
	fi
done

CSI=$($echo -e "\033[")
CEND="${CSI}0m"
CDGREEN="${CSI}32m"
CRED="${CSI}1;31m"
CGREEN="${CSI}1;32m"
CYELLOW="${CSI}1;33m"
CBLUE="${CSI}1;34m"
CMAGENTA="${CSI}1;35m"
CCYAN="${CSI}1;36m"
CQUESTION="$CMAGENTA"
CWARNING="$CRED"
CMSG="$CCYAN"

declare -i I=0
declare -i sum1=0
declare -i sum2=0
for ((I=0;$I <= 255;I++)); do
	ping -c1 -W1 172.16.250.$I &> /dev/null
	check=$?
	if [ "$check" = "0" ]; then
		echo "${CGREEN} 172.16.250.$I ${CEND}"
		let sum1++
	else
		echo "${CWARNING} 172.16.250.$I ${CEND}"
		let sum2++
	fi
done

echo "${CGREEN} has $sum1 IP online. ${CEND}"
echo "${CWARNING} has $sum2 IP offline. ${CEND}"