#!/bin/sh
# File    :   lamp.sh
# Time    :   2019/04/01 23:24:14
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

# httpd define path variable
H_FILES=httpd-2.2.27.tar.bz2
H_FILES_DIR=httpd-2.2.27
H_URL=http://mirrors.cnnic.cn/apache/httpd/
H_PREFIX=/usr/local/apache2/

if [ -z "$1"];then
	echo -e "\033[36m[0]	请选择安装菜单：\033[0m"
	echo -e "\033[32m[1]	编译安装Apache服务器\033[1m"
	echo "[2]	公司产品安装"
	echo "[3]	数据库安装"
	echo "[X]	退出"
	echo -e "\033[31m[100]	Usage:{/bin/sh $0 1|2|3|4|help}\033[0m"
    exit
fi 
if [["$1" -eq "1"]];then
    wget -c $H_URL/$H_FILES &&tar -jxvf $H_FILES &&cd $H_FILES_DIR;./configure --prefix=$H_PREFIX
    if [$? -eq 0];then
        make &&make install
        echo -e"\033[32mThe $H_FILES_DIR Server Install Successfully!\033[0m"
    else
        echo -e"\033[32mThe $H_FILES_DIR Server install Failed,Please check ...\033[0m"
        exit
    fi
fi