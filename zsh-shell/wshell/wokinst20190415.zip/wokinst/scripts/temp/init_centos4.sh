#!/bin/bash

#change network to eth0
sed -i "/linux16.*$/s//& net.ifnames=0 biosdevname=0/g" /boot/grub2/grub.cfg

mv /etc/sysconfig/network-scripts/ifcfg-ens* /etc/sysconfig/network-scripts/ifcfg-eth0
echo "TYPE=Ethernet">/etc/sysconfig/network-scripts/ifcfg-eth0
echo "BOOTPROTO=static">>/etc/sysconfig/network-scripts/ifcfg-eth0
echo "DEFROUTE=yes">>/etc/sysconfig/network-scripts/ifcfg-eth0
echo "NAME=eth0">>/etc/sysconfig/network-scripts/ifcfg-eth0
echo "DEVICE=eth0">>/etc/sysconfig/network-scripts/ifcfg-eth0
echo "ONBOOT=yes">>/etc/sysconfig/network-scripts/ifcfg-eth0
echo "IPADDR=">>/etc/sysconfig/network-scripts/ifcfg-eth0
echo "NETMASK=">>/etc/sysconfig/network-scripts/ifcfg-eth0
echo "GATEWAY=">>/etc/sysconfig/network-scripts/ifcfg-eth0
echo "DNS1=">>/etc/sysconfig/network-scripts/ifcfg-eth0

#change resource limits
sed -i "s/4096/250000/g" /etc/security/limits.d/20-nproc.conf
sed -i "s/#DefaultLimitNPROC=/DefaultLimitNPROC=250000/g" /etc/systemd/system.conf
echo "*             soft    nofile          250000">>/etc/security/limits.conf
echo "*             hard    nofile          250000">>/etc/security/limits.conf

#change selinux disabled
sed -i "s/SELINUX=enforcing/SELINUX=disabled/g" /etc/selinux/config

#change firewalld disable
systemctl disable firewalld

#change NetworkManager disable
systemctl disable NetworkManager

#add history time
echo "export HISTTIMEFORMAT=\"[%Y.%m.%d %H:%M:%S]\"">>/etc/profile
echo "export HISTSIZE=5000">>/etc/profile
echo "export HISTIGNORE=\"ls:ls -lrt:ls -al:clear:pwd\"">>/etc/profile

#change network parameter
echo "netdev_max_backlog = 10240">>/etc/sysctl.d/99-sysctl.conf
echo "net.core.somaxconn = 10240">>/etc/sysctl.d/99-sysctl.conf
echo "net.ipv4.tcp_max_syn_backlog = 10240">>/etc/sysctl.d/99-sysctl.conf

#change hostname && IPaddress
echo -n "Enter the hostname:"
read hostname
hostnamectl set-hostname $hostname
echo -n "Enter the IPaddress:"
read IPaddress
echo -n "Enter the NETMASK:"
read NETMASK
echo -n "Enter the GATEWAY:"
read GATEWAY
echo -n "Enter the DNS1:"
read DNS1
echo "$IPaddress  $hostname">>/etc/hosts
sed -i "s/IPADDR=/IPADDR=$IPaddress/g" /etc/sysconfig/network-scripts/ifcfg-eth0
sed -i "s/NETMASK=/NETMASK=$NETMASK/g" /etc/sysconfig/network-scripts/ifcfg-eth0
sed -i "s/GATEWAY=/GATEWAY=$GATEWAY/g" /etc/sysconfig/network-scripts/ifcfg-eth0
sed -i "s/DNS1=/DNS1=$DNS1/g" /etc/sysconfig/network-scripts/ifcfg-eth0
reboot

#yum install package
yum install -y wget
wget http://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
rpm -ivh epel-release-latest-7.noarch.rpm
yum install -y deltarpm
yum install -y net-tools psmisc tree sysstat perl gcc unzip bzip2 zlib-devel pcre pcre-devel openssl openssl-devel iptraf lsof nmon perf

 包安装说明：

 deltarpm    (安装RPM增量包套件，在更新rpm包时，可以只更新增量内容与旧rpm包合成新包使用，可以减少下载量）

 openssl  openssl-devel  (安装nginx指定ssl加密协议时使用）

 pcre pcre-devel （安装nginx指定正则时使用）

 zlib-devel （安装python及PIP时使用）

 unzip bzip2 （解压工具）

  gcc  （编译器）

 perl  （有些工具需要perl的支持）

 sysstat （使用iostat、mpstat、sar等命令）

 tree （tree命令）

 psmisc （使用killall、fuser、pstree等命令）

 net-tools （使用ifconfig等命令）

 iptraf （linux流量监控工具 新版本的iptraf启动命令为 iptraf-ng）

 lsof （监控和追踪的工具）

 nmon （整体监控工具）

 perf （linux性能分析工具）
--------------------- 
作者：一梦如是YFL 
来源：CSDN 
原文：https://blog.csdn.net/finalkof1983/article/details/80006606 
版权声明：本文为博主原创文章，转载请附上博文链接！




