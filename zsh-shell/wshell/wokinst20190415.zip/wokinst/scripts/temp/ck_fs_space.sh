#!/bin/bash  
# ------------------------------------------------------------------------------+  
#                  CHECK FILE SYSYTEM SPACE BY THRESHOLD                        |  
#   Filename: ck_fs_space.sh                                                    |  
#   Desc:                                                                       |  
#       The script use to check file system space by threshold                  |  
#       Once usage of the disk beyond the threshold, a mail alert will be sent. |     
#       Deploy it by crontab. e.g. per 15 min                                   |    
#   Usage:                                                                      |  
#       ./ck_fs_space.sh <percent> </filesystem [/filesystem2]>                 |    
#                                                                               |  
#   Author : Robinson                                                           |   
#   Blog   : http://blog.csdn.net/robinson_0612                                 |  
# ------------------------------------------------------------------------------+  
#  
# -------------------------------  
#  Set environment here   
# ------------------------------  

# 脚本说明
#    a、该脚本使用了 sendEmail 工具来发送邮件。
#    b、使用方式为"Usage: ck_fs_space.sh 90 / /u01" 。
#    c、脚本中使用了一个while循环来逐个判断所有的指定分区的空闲空间是否超出阙值。
#    d、对于超出阙值的情形发送邮件并且附上当前服务器上磁盘空间的使用情况。

# 转：http://blog.csdn.net/leshami/article/details/8893943

if [ -f ~/.bash_profile ]; then  
    . ~/.bash_profile  
fi  
  
export host=`hostname`  
export mail_dir=/users/robin/dba_scripts/sendEmail-v1.56  
export mail_list='Robinson.cheng@12306.com'  
export mail_fm='oracle@szdb.com'  
tmpfile=/tmp/ck_fs_space.txt  
alert=n  
  
# --------------------------------  
#  Check the parameter  
# --------------------------------  
  
max=$1  
  
if [ ! ${2} ]; then  
    echo "No filesystems specified."  
    echo "Usage: ck_fs_space.sh 90 / /u01"  
    exit 1  
fi  
  
# --------------------------------  
#  Start to check the disk space  
# --------------------------------  
  
while [ "${2}" ]  
    do  
        percent=`df -P ${2} | tail -1 | awk '{print $5 }' | cut -d'%' -f1`  
        if [ "${percent}" -ge "${max}" ]; then  
            alert=y  
            break  
        fi;  
        shift  
    done;  
  
# ------------------------------------------------------------------------  
#  When a partition was above the threshold then send mail with df output  
# ------------------------------------------------------------------------  
  
if [ ! "${alert}" = 'n' ];then  
    df -h >$tmpfile  
    mail_sub="Disk usage beyond the threshold ${max} on ${host}."  
    $mail_dir/sendEmail -u ${mail_sub} -f $mail_fm -t $mail_list -o message-file=${tmpfile}  
fi;  
  
exit;  