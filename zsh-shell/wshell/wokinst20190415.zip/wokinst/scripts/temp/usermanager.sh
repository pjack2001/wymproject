#!/bin/sh
# File    :   usermanager.sh
# Time    :   2019/03/28 18:23:19
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

. /etc/init.d/functions #调用内部函数action

function wait()
{
    echo -n '2秒后继续'
    for ((i=0;i<2;i++))
    do
        echo -n "...";sleep 1
    done
    echo
}
in_check(){
expr $num1 + 1 >/dev/null 2>&1
if [ $? -ne 0 ];then
    echo "please input number"
    exit 1
fi
}
empty_check(){
    if [ ! $name ];then
        echo "The input cannot be empty"
        continue
    fi
}
makedir(){
    dir=/yanglt/
    [ ! -n $dir ]&& mkdir $dir
}

action_check(){
if [ $? -eq 0 ];then
    action "useradd $name successful" /bin/true
else
    action "useradd $name " /bin/false
fi
}
while true
do
cat<<EOF
#################################
1.create user
2.delete user
3.query user
4.exit
################################
EOF
read -p "Please input num:" num
in_check
case "$num" in
    1)
        read -p "please input name:" name
        empty_check
        pass=`mkpasswd -l 8`
        grep -w $name /etc/passwd >/dev/null
        if [ $? -eq 0 ];then
            echo -e "$name already exist"
            exit 1
        else
            makedir
            useradd -s /bin/bash $name &>/dev/null
            echo $pass|passwd --stdin $name &>/dev/null
            action_check
            echo -e "$name\t$pass" >> /yanglt/Passwd.txt
        fi
        ;;
    2)
        read -p "please input delete name:" name
        empty_check
        grep -w $name /etc/passwd >/dev/null
        if [ $? -ne 0 ];then
            echo -e "$name is not exist"
            exit 0
        else
            userdel -r $name
            sed -i "/^$name$/d" /yanglt/Passwd.txt #进一步了解精确匹配，和变量匹配
            echo -e "$name delete successful"
        fi
        ;;
    3)
        read -p "please input need query name:" name
        empty_check
        grep -w $name /etc/passwd >/dev/null  #-w 精确匹配
        if [ $? -eq 0 ];then
            grep -w "$name" /etc/passwd
            grep -w "$name" /yanglt/Passwd.txt 
        else
            echo -e "$name is not exist"
            continue
            fi
        ;;
   *)
        exit 1
        ;;
esac
wait
done