#!/bin/bash
#https://www.cnblogs.com/bingo1024/p/10423661.html 
#[root@ansible_50 ansible]$ yum install expect -y
# [root@ansible_50 ansible]$ cd /root/.ssh/
# [root@ansible_50 .ssh]$ vim push_ssh.sh


#ip地址文件
>ip_list.txt
>/root/.ssh/known_hosts

#生成公钥
if [ ! -f ~/.ssh/id_rsa.pub ];then
        ssh-keygen -P "" -f ~/.ssh/id_rsa
        exit
fi

#下载expect
rpm -q expect &>/dev/null
if [ $? -ne 0 ];then
yum -y install expect
fi

#推送公钥到被管理端
for i in {50..55}  #被管理主机IP
do
{
ip=10.0.0.$i
ping -c1 -W1 $ip &>/dev/null
if [ $? -eq 0 ];then
echo $ip >> ip_list.txt
/usr/bin/expect <<-EOF
set timeout 10
spawn ssh-copy-id -i $ip
expect {
"*yes/no" { send "yes\r"; exp_continue}
"*password:" { send "123456\r" }  #被管理端密码
}
expect "#"
send "exit\r"
expect eof
EOF
fi
}&
done

wait 
echo "finish...."

#测试秘钥是否推送成功
# [root@ansible_50 ansible]$ ansible all -m ping
# 10.0.0.52 | SUCCESS => {
#     "changed": false, 
#     "ping": "pong"
# }
# 10.0.0.53 | SUCCESS => {
#     "changed": false, 
#     "ping": "pong"
# }
# 10.0.0.54 | SUCCESS => {
#     "changed": false, 
#     "ping": "pong"
# }
# 10.0.0.51 | SUCCESS => {
#     "changed": false, 
#     "ping": "pong"
# }
# [root@ansible_50 ansible]$