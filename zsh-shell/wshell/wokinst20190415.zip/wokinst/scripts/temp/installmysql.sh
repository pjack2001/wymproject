#!/bin/sh
# File    :   installmysql.sh
# Time    :   2019/03/28 18:20:47
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

#1.安装wget
yum -y install  wget
#2、下载mysql的yum源
URL="https://repo.mysql.com//mysql80-community-release-el7-1.noarch.rpm"
wget $URL -P /etc/yum.repos.d/
yum -y install yum-utils   #如果没有该包，下边执行yum-config-manager不生效
yum -y install /etc/yum.repos.d/mysql80-community-release-el7-1.noarch.rpm
    if [ $? -eq 0 ];then
        rm -rf /etc/yum.repos.d/mysql80-community-release-el7-1.noarch*
    fi
yum-config-manager --disable mysql80-community
yum-config-manager --enable mysql57-community
yum -y install mysql-community-server
    sleep 5
    systemctl start mysqld   
    systemctl enable mysqld
    systemctl status mysqld
    if [ $? -eq 0 ];then
        echo -e "install succefull"
        result="`grep 'temporary password' /var/log/mysqld.log`"
        p1="`echo $result |awk '{print $NF}'`"
        echo "数据库密码为:$p1"
    
    fi