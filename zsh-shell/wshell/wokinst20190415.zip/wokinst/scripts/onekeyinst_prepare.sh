#!/bin/sh
# File    :   onekeyinst_prepare.sh
# Time    :   2019/04/10 15:57:16
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

export PATH=/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/sbin:/usr/local/bin
clear
# ------------定义路径----------------
#basepath=$(cd `dirname $0`; pwd)
. ../conf/color.conf
. ../conf/system.conf
# . ./scripts/common.sh
#. ./scripts/check.sh
#. ./scripts/check_host.sh
#. ./scripts/init_host.sh
#. ./scripts/.sh
#. ./scripts/envcheck.sh
. ./download.sh
#. ./create_localrepo.sh
#. ./scripts/inst_soft.sh
#. ./scripts/inst_nginx.sh
#. ./scripts/inst_keepalived.sh
#. ./scripts/.sh
#. ./scripts/.sh
#. ./scripts/jdk-1.8.sh
#. ./scripts/mysql-5.7.sh
#. ./scripts/thingslink.sh
# . ./scripts/tomcat-8.sh

# Check if user is root
[ $(id -u) != "0" ] && { echo "${CFAILURE}Error: You must be root to run this script${CEND}"; exit 1; }

#wokinst_dir=$(dirname "`readlink -f $0`")
#pushd ${wokinst_dir} > /dev/null

# ----------------定义全局变量-----------
logfile=${prepath}/logs/install.log
readmefile=${prepath}/readme.txt

 echo -e "basepath目录："$basepath
 echo -e "prepath目录："$prepath
 echo -e "pprepath目录："$pprepath
 echo -e "rpmdir目录："$rpmdir
 echo -e "rpv目录："$rpv
 echo -e "srcdir目录："$srcdir

echo "${CMSG}############ 下载阿里源文件，过程开始 ############${CEND}"
	Download_Aliyunrepo 2>&1 | tee -a ${logfile}
echo "${CMSG}############ 下载阿里源文件，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}配置阿里源失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}配置阿里源成功！${CEND}"
			echo ""
		fi

echo "${CMSG}############ 下载本地RPM包文件，过程开始 ############${CEND}"
	Download_Rpm 2>&1 | tee -a ${logfile}
echo "${CMSG}############ 下载本地RPM包文件，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}下载本地RPM包文件失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}下载本地RPM包文件成功！${CEND}"
			echo ""
		fi
