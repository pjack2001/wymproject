#!/bin/sh
# File    :   create_localrepo.sh
# Time    :   2019/04/08 13:07:21
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

Create_Rpmrepo() {
    #rpm -ivh $rpv/deltarpm-3.6-3.el7.x86_64.rpm
    rpm -ivh $rpv/python-deltarpm-3.6-3.el7.x86_64.rpm
    #rpm -ivh $rpv/libxml2-python-2.9.1-6.el7_2.3.x86_64.rpm
    rpm -ivh $rpv/createrepo-0.9.9-28.el7.noarch.rpm

    Is_Yum_Avaliable=`which yum`
    if [[ Is_Yum_Available == "" ]]; then
        echo -e "Info: Please make sure yum command is available"
        exit 1
    fi

    echo -e "rpm包路径：" $rpv

    echo -n -e "\e[1;31m****** 本地rpm包路径:\e[0m"
    echo $rpv

    mv /etc/yum.repos.d/*.repo /etc/yum.repos.d/repo_bak/
    # 使用createrepo生成符合要求的yum仓库
    createrepo $rpv
    
    #localrepo
    #read -p "请输入本地rpm包源名称:默认localrepo" name
    #if [ -z "$name" ];then
        name="localrepo"
    #fi

    repoName="$name".repo
    repoPath="/etc/yum.repos.d/${name}.repo"
    
    if [[ -f $repoName ]]; then
        echo -e "Info: 文件 $repoName 已经存在"
        exit 1
    fi
    touch $repoPath
    chmod 644 $repoPath
    echo "[localrepos]" >> $repoPath
    echo "name=$name" >> $repoPath
    echo "baseurl=file://$rpv" >> $repoPath
    echo "enabled=1" >> $repoPath
    echo "gpgcheck=0" >> $repoPath
    
    yum clean all
    yum makecache

    echo -e $(yum repolist)
    echo -e "\e[1;31m****** 本地rpm包YUM源安装成功 ******\e[0m"
}

Create_Isorepo() {

Is_Yum_Avaliable=`which yum`
if [[ Is_Yum_Available == "" ]]; then
	echo -e "Info: Please make sure yum command is available"
	exit 1
fi

#CDROMPath=${basepath}/cdrom
CDROMPath=/opt/cdrom
[ ! -d ${CDROMPath} ] && mkdir -p ${CDROMPath}

isopath=`ls /opt/*.iso`
echo "ISO光盘路径isopath：" $isopath
isotmp=${isopath##*/}
isoname=${isotmp%.*}
#echo "ISO光盘文件名isotmp：" $isotmp #显示文件名+后缀
echo "ISO光盘文件名isoname：" ${isoname} #显示文件名

if [[ ! -f $isopath ]]; then
	echo -e "Info: 文件 $isoname 不存在"
	exit 1
    else echo -e "Info: 文件 $isoname 存在"
fi

#挂载光盘
#mount -t iso9660 -o loop /opt/CentOS-7-x86_64-DVD-1804.iso /opt/cdrom/
mount -t iso9660 -o loop $isopath $CDROMPath
if [ $(echo $?) -eq 0 ]
    then
     echo "光盘挂载成功!"
    else
     echo "光盘挂载失败!"
fi

#localiso 
name2="localiso"

repoName2="$name2".repo
repoPath2="/etc/yum.repos.d/${name2}.repo"
 
if [[ -f $repoPath2 ]]; then
	echo -e "Info: 文件 $repoPath2 已经存在"
	exit 1
fi
touch $repoPath2
chmod 644 $repoPath2
echo "[localisorepos]" >> $repoPath2
echo "name=$name2" >> $repoPath2
echo "baseurl=file://$CDROMPath" >> $repoPath2
echo "enabled=1" >> $repoPath2
echo "gpgcheck=0" >> $repoPath2
 
yum clean all
yum makecache
 
echo -e $(yum repolist)
echo -e "\e[1;31m****** 本地光盘YUM源安装成功 ******\e[0m"
}

Create_Isohttprepo() {
Is_Yum_Avaliable=`which yum`
if [[ Is_Yum_Available == "" ]]; then
	echo -e "Info: Please make sure yum command is available"
	exit 1
fi

#注意不要和nginx的80端口冲突
yum install -y httpd && systemctl start httpd.service && systemctl stop firewalld.service
if [ $(echo $?) -eq 0 ]
    then
     echo "httpd install Success!"
    else
     echo "httpd install Failed!"
fi

[ -n "/etc/httpd/conf/httpd.conf" ]||{
        echo Error:Apache is not installed 
        exit
}

IpPort=8001

sed "/^Listen/cListen ${IpPort}"  -i /etc/httpd/conf/httpd.conf
systemctl restart httpd

httpCDPath="/var/www/html/centos/7/os/x86_64/"
[ ! -d ${httpCDPath} ] && mkdir -p ${httpCDPath}


isopath=`ls /opt/*.iso`
echo "ISO光盘路径isopath：" $isopath
isotmp=${isopath##*/}
isoname=${isotmp%.*}
#echo "ISO光盘文件名isotmp：" $isotmp #显示文件名+后缀
echo "ISO光盘文件名isoname：" ${isoname} #显示文件名

if [[ ! -f $isopath ]]; then
	echo -e "Info: 文件 $isoname 不存在"
	exit 1
    else echo -e "Info: 文件 $isoname 存在"
fi

#挂载光盘
#mount -t iso9660 -o loop /opt/CentOS-7-x86_64-DVD-1804.iso /opt/cdrom/
mount -t iso9660 -o loop $isopath $httpCDPath
if [ $(echo $?) -eq 0 ]
    then
     echo "光盘挂载成功!"
    else
     echo "光盘挂载失败!"
fi

#locahttpd 
name3="localhttpd"

# 得到eth1网卡的IP地址

echo "网卡名称：" $node1Networkcard
#echo "网卡IP：" $node1

ipaddr=$(ifconfig ${node1Networkcard} |grep -o "[0-9.]\{7,\}" |head -n1)
echo -e "${node1Networkcard}网卡的IP地址：" $ipaddr

ver=$(rpm -q --qf %{version} centos-release;echo)
arch=$(rpm -q --qf %{arch} centos-release;echo)

repoName3="$name3".repo
repoPath3="/etc/yum.repos.d/${name3}.repo"

if [[ -f $repoPath3 ]]; then
	echo -e "Info: The file $repoPath3 already exist"
	exit 1
fi
touch $repoPath3
chmod 644 $repoPath3
echo "[localisorepos]" >> $repoPath3
echo "name=$name3" >> $repoPath3
echo "baseurl=http://$ipaddr:${IpPort}/centos/$ver/os/$arch" >> $repoPath3
echo "gpgkey=http://$ipaddr:${IpPort}/centos/$ver/os/x86_64/RPM-GPG-KEY-CentOS-$ver" >> $repoPath3
echo "enabled=1" >> $repoPath3
echo "gpgcheck=1" >> $repoPath3

#http://$ipaddr/centos/7/os/x86_64/
#echo "baseurl=http://$ipaddr/centos/$releasever/os/$basearch"
#echo "gpgkey=http://$ipaddr/centos/$releasever/os/x86_64/RPM-GPG-KEY-CentOS-$releasever" 

yum clean all
yum makecache

echo -e $(yum repolist)
echo -e "\e[1;31m****** 本地网络YUM源安装成功 ******\e[0m"

}