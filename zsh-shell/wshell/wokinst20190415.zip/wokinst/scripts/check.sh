#!/bin/sh
# File    :   check.sh
# Time    :   2019/04/03 11:15:02
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

#exit（0）：正常运行程序并退出程序；
#exit（1）：非正常运行导致退出程序；

#系统检测脚本
#防火墙状态，selinux状态
#用户，


check_script() {
if [ ! -f $1 ];then
 echo '---------脚本不存在.---------'
 exit 1 
fi
if [ ! -x $1 ];then
 echo '---------脚本不可执行.---------'
 exit 2
fi
}

check_dir() {
if [ ! -d $1 ];then
 echo '---------目录不存在.---------'
 exit 1
fi
}

check_os() {
if [ -n "$(grep 'Aliyun Linux release' /etc/issue)" -o -e /etc/redhat-release ]; then
  OS=CentOS
  [ -n "$(grep ' 7\.' /etc/redhat-release 2> /dev/null)" ] && CentOS_ver=7
  [ -n "$(grep ' 6\.' /etc/redhat-release 2> /dev/null)" -o -n "$(grep 'Aliyun Linux release6 15' /etc/issue)" ] && CentOS_ver=6
  [ -n "$(grep ' 5\.' /etc/redhat-release 2> /dev/null)" -o -n "$(grep 'Aliyun Linux release5' /etc/issue)" ] && CentOS_ver=5
elif [ -n "$(grep 'Amazon Linux AMI release' /etc/issue)" -o -e /etc/system-release ]; then
  OS=CentOS
  CentOS_ver=6
fi

if [ "$(getconf WORD_BIT)" == "32" ] && [ "$(getconf LONG_BIT)" == "64" ]; then
  OS_BIT=64
  SYS_BIT_j=x64 #jdk
  SYS_BIT_a=x86_64 #mariadb
  SYS_BIT_b=x86_64 #mariadb
  SYS_BIT_c=x86_64 #ZendGuardLoader
  SYS_BIT_d=x86-64 #ioncube
else
  OS_BIT=32
  SYS_BIT_j=i586
  SYS_BIT_a=x86
  SYS_BIT_b=i686
  SYS_BIT_c=i386
  SYS_BIT_d=x86
fi
}

Get_Dist_Name(){
    if grep -Eqii "CentOS" /etc/issue || grep -Eq "CentOS" /etc/*-release; then
        DISTRO='CentOS'
        PM='yum'
    elif grep -Eqi "Red Hat Enterprise Linux Server" /etc/issue || grep -Eq "Red Hat Enterprise Linux Server" /etc/*-release; then
        DISTRO='RHEL'
        PM='yum'
    elif grep -Eqi "Aliyun" /etc/issue || grep -Eq "Aliyun" /etc/*-release; then
        DISTRO='Aliyun'
        PM='yum'
    elif grep -Eqi "Fedora" /etc/issue || grep -Eq "Fedora" /etc/*-release; then
        DISTRO='Fedora'
        PM='yum'
    elif grep -Eqi "Debian" /etc/issue || grep -Eq "Debian" /etc/*-release; then
        DISTRO='Debian'
        PM='apt'
    elif grep -Eqi "Ubuntu" /etc/issue || grep -Eq "Ubuntu" /etc/*-release; then
        DISTRO='Ubuntu'
        PM='apt'
    elif grep -Eqi "Raspbian" /etc/issue || grep -Eq "Raspbian" /etc/*-release; then
        DISTRO='Raspbian'
        PM='apt'
    else
        DISTRO='unknow'
    fi
    echo $DISTRO;
}

# v=`cat /etc/redhat-release|sed -r 's/.* ([0-9]+)\..*/\1/'`
# if [ $v -eq 6 ]; then
#     echo "centos 6"
# fi
# #  centos-7:
# if [ $v -eq 7 ]; then
#     echo "centos 7"
# fi
#不同版本，文件夹名称不同


Disk_Check(){
#取得每个分区的使用百分比（不要百分号）
#percent=`df -k | grep -v Filesystem| awk '{print int($5)}'`
percent=`df -h |grep ^/dev/ | awk '{print int($5)}'`
percent2=`df -h |grep ^/dev/ | awk '{print $1}'`
#循环判断分区使用率是否超过90%
for each_one in $percent
do
        #判断使用率是否超过90%
        if [ $each_one -ge 10 ];then
                #如果超过90 则把使用情况发给mail_address mail_address换成你的邮件地址
                #df | mail -s "Disk Critical" mail_address
                echo "磁盘空间${percent2}占比${percent}， 超过90%"
        else 
            echo "磁盘空间${percent2}占比${percent}， 正常"
        fi
done
}

