#!/bin/sh
# File    :   inst_keepalived.sh
# Time    :   2019/04/11 13:03:12
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

#dir=/data
#keepalived_download_path="https://www.keepalived.org/software/keepalived-2.0.13.tar.gz"
#keepalived_install_dir="/usr/local/keepalived"
#keepalived_name="keepalived-2.0.13.tar.gz"

[ -f /etc/init.d/functions ] && . /etc/init.d/functions || exit 1

install_keepalived(){

# # -------------------------------------------------------- #
# ## Ipvsadm_install
# # -------------------------------------------------------- #
# # ipvsadm installation
# CURRENT_PATH=$(pwd)
# for i in $(rpm -q gcc gcc-c++ kernel-devel openssl-devel popt-devel popt-static libnl-devel |grep 'not installed' | awk '{print $2}')
# do
# yum -y install $i
# done
# [ -d ${CURRENT_PATH}/software ]
# [ "$?" != 0 ] && mkdir ${CURRENT_PATH}/software
# cd ${CURRENT_PATH}/software
# [ ! -e ipvsadm-1.26.tar.gz ] && wget http://www.linuxvirtualserver.org/software/kernel-2.6/ipvsadm-1.26.tar.gz
# tar -zxvf ipvsadm-1.26.tar.gz
# cd ipvsadm-1.26
# make && make install
# echo $? || [ $? != 0 ] || echo " installation ipvsadm failed" || exit 1
# echo "modprobe ip_vs" >> /etc/rc.local
# # ipvsadm start-up
# [ -x ${CURRENT_PATH}/scripts/ipvsadm ] && [ "$?" != 0 ] && chmod 755 ${CURRENT_PATH}/scripts/ipvsadm
# cp ${CURRENT_PATH}/scripts/ipvsadm /etc/init.d/
# chkconfig --add ipvsadm
# chkconfig --level 345 ipvsadm on
# service ipvsadm start
# -------------------------------------------------------- #
## Keepalived_intsall
# -------------------------------------------------------- #
# Keepalived installation
# cd ${CURRENT_PATH}/software
# [ ! -e keepalived-1.2.4.tar.gz ] && wget http://www.keepalived.org/software/keepalived-1.2.4.tar.gz
  [ -e $srcdir ] && cd $srcdir
  if [ -f $keepalived_name ]
    then
      echo 'keepalived file exit！'
      # tar keepalived
      tar -zxf ${keepalived_name} && cd ${keepalived_name2}
      [ $(echo $?) -eq 0 ] && ./configure --prefix=${keepalived_install_dir}
      [ $(echo $?) -eq 0 ] && make && make install
      [ $(echo $?) -eq 0 ] && echo "keepalived install success"
      echo $? || [ $? != 0 ] || print " keepalived install failed" || exit 1
  fi
}

# start nginx
start_keepalived(){
    systemctl start keepalived
    systemctl enable keepalived
}

stop_keepalived(){
    systemctl stop keepalived
    #systemctl disable keepalived
}
