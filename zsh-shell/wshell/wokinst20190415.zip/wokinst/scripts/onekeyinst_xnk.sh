#!/bin/sh
# File    :   onekeyinst_xnk.sh
# Time    :   2019/04/11 13:38:01
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

export PATH=/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/sbin:/usr/local/bin
clear
# ------------定义路径----------------
#basepath=$(cd `dirname $0`; pwd)
. ../conf/color.conf
. ../conf/system.conf
# . ./scripts/common.sh
#. ./scripts/check.sh
#. ./scripts/check_host.sh
. ./init_host.sh
#. ./scripts/.sh
#. ./scripts/envcheck.sh
. ./download.sh
. ./create_localrepo.sh
. ./inst_soft.sh
. ./inst_nginx.sh
. ./inst_keepalived.sh
#. ./scripts/.sh
#. ./scripts/.sh
#. ./scripts/jdk-1.8.sh
#. ./scripts/mysql-5.7.sh
#. ./scripts/thingslink.sh
# . ./scripts/tomcat-8.sh

# Check if user is root
[ $(id -u) != "0" ] && { echo "${CFAILURE}Error: You must be root to run this script${CEND}"; exit 1; }

#wokinst_dir=$(dirname "`readlink -f $0`")
#pushd ${wokinst_dir} > /dev/null

# ----------------定义全局变量-----------
logfile=${prepath}/logs/install.log
readmefile=${prepath}/readme.txt


 echo -e "current_path目录："$current_path
 echo -e "basepath目录："$basepath
 echo -e "prepath目录："$prepath
 echo -e "pprepath目录："$pprepath
 echo -e "rpmdir目录："$rpmdir
 echo -e "rpv目录："$rpv
 echo -e "srcdir目录："$srcdir


    echo "${CMSG}############ 一键安装nginx和keepalived、配置、启动，过程开始 ############${CEND}"
	install_keepalived 2>&1 | tee -a ${logfile}
	install_nginx 2>&1 | tee -a ${logfile}
    start_keepalived 2>&1 | tee -a ${logfile}
    start_nginx 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 一键安装nginx和keepalived、配置、启动，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}一键安装nginx和keepalived、配置、启动失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}一键安装nginx和keepalived、配置、启动成功！${CEND}"
			echo ""
		fi	

