#!/bin/sh
# File    :   download.sh
# Time    :   2019/04/08 14:08:40
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

Download_Aliyunrepo() {
    Is_Yum_Avaliable=`which yum`
    if [[ Is_Yum_Available == "" ]]; then
        echo -e "Info: Please make sure yum command is available"
        exit 1
    fi    

    yum install wget -y;cd /etc/yum.repos.d/ && mkdir repo_bak && mv *.repo repo_bak/
    wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
    wget -O /etc/yum.repos.d/epel-7.repo http://mirrors.aliyun.com/repo/epel-7.repo
    wget -O /etc/yum.repos.d/docker-ce.repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
    yum clean all && yum makecache && yum repolist
    ls -a /etc/yum.repos.d/
}

Download_Rpm() {

echo "${CMSG}############ 下载RPM包，过程开始 ############${CEND}"
echo -e "CentOS版本：" $centos_ver

#/opt/wokinst/files/rpmpackages/7.4.1708
echo -e "rpm包目录默认值："$rpv
#read -p "请输入本地rpm包路径:" CDPath
# if [ -z "$CDPath" ];then #如果没有输入，取默认值
#     CDPath=$rpmdir 
# fi
# check_dir $CDPath

#/oracle/wokishell/wokinst/rpmpackages/7.4.1708
[ ! -d ${rpv} ] && mkdir -p ${rpv}
#常用软件包
yum install -y wget vim tree net-tools ntp createrepo expect deltarpm psmisc sysstat perl unzip bzip2 iptraf lsof nmon perf httpd tmux pip --downloadonly --downloaddir=$rpv
#其他
#软件包
yum install -y ansible docker-ce-18.06.1.ce --downloadonly --downloaddir=$rpv
#keepalived和nginx依赖
yum install -y gcc gcc-c++ openssl openssl-devel popt-devel pcre pcre-devel make zlib zlib-devel autoconf automake --downloadonly --downloaddir=$rpv
yum -y install libnl libnl-devel libnfnetlink libnfnetlink-devel --downloadonly --downloaddir=$rpv
echo "${CMSG}############ 下载RPM包，过程结束 ############${CEND}"
}
