#!/bin/sh
# File    :   prepare.sh
# Time    :   2019/04/08 11:50:25
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

Necessary_Install(){
    yum install -y wget vim tree net-tools ntp createrepo expect deltarpm psmisc sysstat perl unzip bzip2 iptraf lsof nmon perf httpd tmux pip
    yum install -y gcc gcc-c++ openssl openssl-devel popt-devel pcre pcre-devel make zlib zlib-devel autoconf automake
    yum -y install libnl libnl-devel libnfnetlink libnfnetlink-devel
    # for i in $(rpm -q wget vim tree net-tools ntp createrepo expect deltarpm psmisc sysstat perl unzip bzip2 iptraf lsof nmon perf httpd tmux pip gcc gcc-c++ openssl openssl-devel popt-devel pcre pcre-devel make zlib zlib-devel autoconf automake libnl libnl-devel libnfnetlink libnfnetlink-devel |grep 'not installed' | awk '{print $2}')
    # do
    # yum -y install $i
    # done
}

Install_Ansible(){
    yum install -y ansible
}
Install_Docker(){
    yum install -y docker-ce-18.06.1.ce
}

Start_Docker(){
    systemctl start docker
    systemctl enable docker
}