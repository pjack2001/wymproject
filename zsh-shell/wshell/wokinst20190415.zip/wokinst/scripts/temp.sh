#!/bin/sh
# File    :   temp.sh
# Time    :   2019/04/08 13:09:10
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

# ------------定义路径----------------
#相关路径变量在syste.conf文件里设定
. ../conf/color.conf
. ../conf/system.conf
. ./check.sh
#. ./check.sh


echo -e "rpmdir目录："$rpmdir
echo -e "rpv目录："$rpv

echo -e "\e[1;31m****** temp ******\e[0m"

Disk_Check

echo -e "\e[1;31m****** temp ******\e[0m"
