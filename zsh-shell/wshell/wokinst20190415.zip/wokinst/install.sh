#!/bin/sh
# File    :   install.sh
# Time    :   2019/04/02 16:14:49
# Author  :   wangyuming 
# Version :   0.1
# License :   (C)Copyright 2018-2019, MIT
# Desc    :   None

export PATH=/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/sbin:/usr/local/bin
clear
# ------------定义路径----------------
#basepath=$(cd `dirname $0`; pwd)
. ./conf/color.conf
. ./conf/system.conf
# . ./scripts/common.sh
#. ./scripts/check.sh
#. ./scripts/check_host.sh
. ./scripts/init_host.sh
#. ./scripts/.sh
. ./scripts/envcheck.sh
. ./scripts/download.sh
. ./scripts/create_localrepo.sh
. ./scripts/inst_soft.sh
. ./scripts/inst_nginx.sh
. ./scripts/inst_keepalived.sh
#. ./scripts/.sh
#. ./scripts/.sh
. ./scripts/inst_jdk-1.8.sh
. ./scripts/inst_mariadb-10.3.sh
. ./scripts/thingslink.sh
# . ./scripts/tomcat-8.sh

# Check if user is root
[ $(id -u) != "0" ] && { echo "${CFAILURE}Error: You must be root to run this script${CEND}"; exit 1; }

#wokinst_dir=$(dirname "`readlink -f $0`")
#pushd ${wokinst_dir} > /dev/null

# ----------------定义全局变量-----------
#logfile=${basepath}/logs/install.log
logfile=${logsdir}/install.log
readmefile=${basepath}/readme.txt

echo "${CMSG}###################一键安装程序###################${CEND}"
echo ""
#主菜单
function menu()
{
echo -e `date`
cat <<EOF
${CMSG}============ 一键安装程序主菜单 ============${CEND}
`echo -e " [0]    查看帮助文档"`
`echo -e " [1]    通用环境检查配置安装"`
`echo -e " [2]    公司产品安装配置"`
`echo -e " [3]    Oracle数据库"`
`echo -e " [q]    退出"`
${CMSG}============ 请选择操作的选项 ============${CEND}
EOF

while :; do
#显示目录，调试用
Check_Dir
read -p "请输入对应序列号：" num1
case $num1 in
    0)
    # 显示帮助问题文档
    clear
    help_menu
    ;;
    1)
    clear
    echo -e "$CGREEN >>>通用环境检查配置安装-> $CEND"
    system_menu
    ;;
    2)
    clear
    echo -e "$CGREEN >>>公司产品安装配置-> $CEND"
    server_menu
    ;;
    3)
    clear
    echo -e "$CGREEN >>>Oracle数据库安装配置-> $CEND"
    db_menu
    ;;
    Q|q)
    clear
    echo -e "$CGREEN--------退出--------- $CEND"
    exit 0
    ;;
    "")
    ;; #如果什么都不输入，换行，也不报错
    *)
    clear
    echo -e "$CRED err：请输入正确的编号$CEND"
    menu
esac
done
}
#二级菜单
function help_menu()
{
cat<<EOF
${CMSG}============ 帮助和教程 ============${CEND}
`echo -e " [1]    0.0帮助文档"`
`echo -e " [2]    0.1教程1（脚本操作）"`
`echo -e " [3]    0.2教程2（制作离线安装包，离线yum源）"`
`echo -e " [4]    0.3教程3（一键安装必备软件）"`
`echo -e " [5]    0.4教程4（一键安装公司产品）"`
`echo -e " [x]    返回主菜单"`
`echo -e " [q]    退出"`
${CMSG}============ 请选择操作的选项 ============${CEND}
EOF
while :;do
read -p "请输入编号:" num2
case $num2 in
    1)
    echo ""
    cat $readmefile
    echo ""
    echo ""
    help_menu
    ;;
    2)
    clear
    scriptreplay timing.log output.session
    help_menu
    ;;
    3)
    clear
    scriptreplay timing.log output.session
    help_menu
    ;;
    4)
    clear
    scriptreplay timing.log output.session
    help_menu
    ;;
    x|X)
    clear
    echo -e "\033[32m---------返回上一级目录------->\033[0m"
    menu
    ;;
    Q|q)
    echo -e "$CGREEN--------退出--------- $CEND"
    exit 0
    ;;
    "")
    ;; #如果什么都不输入，什么都不做，也不报错
    *)
    echo -e "请输入正确编号"
    help_menu
esac
done
}
#二级菜单
function system_menu()
{
cat<<EOF
${CMSG}============ 通用环境检查配置安装 ============${CEND}
`echo -e " [1]    1.1通用环境检查"`
`echo -e " [2]    1.2YUM源配置（可选）"`
`echo -e " [3]    1.3通用环境配置安装"`
`echo -e " [x]    返回主菜单"`
`echo -e " [q]    退出"`
${CMSG}============ 请选择操作的选项 ============${CEND}
EOF
while :;do
read -p "请输入编号:" num2
case $num2 in
    1)
    clear
    EnvCheck 2>&1 | tee -a ${logfile}
    system_menu
    ;;
    2)
    clear
    yum_menu
    ;;
    3)
    clear
    instsoft_menu
    ;;
    x|X)
    clear
    echo -e "\033[32m---------返回上一级目录------->\033[0m"
    menu
    ;;
    Q|q)
    echo -e "$CGREEN--------退出--------- $CEND"
    exit 0
    ;;
    "")
    ;; #如果什么都不输入，什么都不做，也不报错
    *)
    echo -e "请输入正确编号"
    system_menu
esac
done
}
#二级菜单
function server_menu()
{
cat<<EOF
${CMSG}============ 公司产品一键安装配置 ============${CEND}
`echo -e " [1]    2.1虚拟卡nginx+keepalived"`
`echo -e " [2]    2.2物联网安装"`
`echo -e " [x]    返回主菜单"`
`echo -e " [q]    退出"`
${CMSG}============ 请选择操作的选项 ============${CEND}
EOF

while :;do
read -p "请输入编号:" num3
case $num3 in
    1)
    clear
    xnk_menu
    ;;
    2)
    clear
    wlw_menu
    ;;
    x|X)
    clear
    echo -e "\033[32m---------返回上一级目录------->\033[0m"
    menu
    ;;
    Q|q)
    echo -e "$CGREEN--------退出--------- $CEND"
    exit 0
    ;;
    "")
    ;; #如果什么都不输入，什么都不做，也不报错
    *)
    echo -e "请输入正确编号"
    system_menu
esac
done
}
#三级菜单
function yum_menu()
{
cat<<EOF
${CMSG}============ YUM源配置 ============${CEND}
`echo -e " [1]    1.2.1配置阿里源（在线）"`
`echo -e " [2]    1.2.2下载本地RPM包（在线）"`
`echo -e " [3]    1.2.3配置本地RPM包源（离线）【必选】"`
`echo -e " [4]    1.2.4配置ISO光盘源（离线）【可选】"`
`echo -e " [5]    1.2.5配置ISO光盘网络源（离线）【可选】"`
`echo -e " [x]    返回主菜单"`
`echo -e " [q]    退出"`
${CMSG}============ 请选择操作的选项 ============${CEND}
EOF
while :;do
read -p "请输入编号:" yumnum
case $yumnum in
    1)
    clear
    echo "${CMSG}############ 下载阿里源文件，过程开始 ############${CEND}"
	Download_Aliyunrepo 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 下载阿里源文件，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}配置阿里源失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}配置阿里源成功！${CEND}"
			echo ""
		fi
    yum_menu
    ;;
    2)
    clear
    echo "${CMSG}############ 下载本地RPM包文件，过程开始 ############${CEND}"
	Download_Rpm 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 下载本地RPM包文件，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}下载本地RPM包文件失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}下载本地RPM包文件成功！${CEND}"
			echo ""
		fi
    yum_menu
    ;;
    3)
    clear
    echo "${CMSG}############ 配置本地RPM包源，过程开始 ############${CEND}"
	Create_Rpmrepo 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 配置本地RPM包源，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}配置本地RPM包源失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}配置本地RPM包源成功！${CEND}"
			echo ""
		fi
    yum_menu
    ;;
    4)
    clear
    echo "${CMSG}############ 配置ISO光盘源，过程开始 ############${CEND}"
	Create_Isorepo 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 配置ISO光盘源，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}配置ISO光盘源失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}配置ISO光盘源成功！${CEND}"
			echo ""
		fi
    yum_menu
    ;;
    5)
    clear
    echo "${CMSG}############ 配置ISO光盘网络源，过程开始 ############${CEND}"
	Create_Isohttprepo 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 配置ISO光盘网络源，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}配置ISO光盘网络源失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}配置ISO光盘网络源成功！${CEND}"
			echo ""
		fi
    yum_menu
    ;;
    x|X)
    clear
    echo -e "\033[32m---------返回上一级目录------->\033[0m"
    system_menu
    ;;
    Q|q)
    echo -e "$CGREEN--------退出--------- $CEND"
    exit 0
    ;;
    "")
    ;; #如果什么都不输入，什么都不做，也不报错
    *)
    echo -e "请输入正确编号"
    yum_menu
esac
done
}
#三级菜单
function instsoft_menu()
{
cat<<EOF
${CMSG}============ 通用环境安装 ============${CEND}
`echo -e " [1]    1.3.1预安装准备：关闭防火墙selinux，配置时区"`
`echo -e " [2]    1.3.2安装必备软件wget、vim等"`
`echo -e " [3]    1.3.3安装ansible"`
`echo -e " [4]    1.3.4安装docker-ce"`
`echo -e " [5]    1.3.5安装Java"`
`echo -e " [6]    1.3.6安装MariaDB"`
`echo -e " [x]    返回主菜单"`
`echo -e " [q]    退出"`
${CMSG}============ 请选择操作的选项 ============${CEND}
EOF
while :;do
read -p "请输入编号:" instnum
case $instnum in
    1)
    clear
    echo "${CMSG}############ 预安装准备，过程开始 ############${CEND}"
	Init_Host 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 预安装准备，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}预安装准备失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}预安装准备成功！${CEND}"
			echo ""
		fi
    instsoft_menu
    ;;
    2)
    clear
    echo "${CMSG}############ 必备软件安装，过程开始 ############${CEND}"
	Necessary_Install 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 必备软件安装，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}必备软件安装失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}必备软件安装成功！${CEND}"
			echo ""
		fi
    instsoft_menu
    ;;
    3)
    clear
    echo "${CMSG}############ 安装ansible，过程开始 ############${CEND}"
	Install_Ansible 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 安装ansible，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}安装ansible失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}安装ansible成功！${CEND}"
			echo ""
		fi
    instsoft_menu
    ;;
    4)
    clear
    echo "${CMSG}############ 安装Docker，过程开始 ############${CEND}"
	Install_Docker 2>&1 | tee -a ${logfile}
	Start_Docker 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 安装Docker，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}安装Docker失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}安装Docker成功！${CEND}"
			echo ""
		fi    
    instsoft_menu
    ;;
    5)
    clear
    echo "${CMSG}############ 安装JDK1.8，过程开始 ############${CEND}"
	Install_JDK 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 安装JDK1.8，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}安装JDK1.8失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}安装JDK1.8成功！${CEND}"
			echo ""
		fi    
    instsoft_menu
    ;;
    6)
    clear
    echo "${CMSG}############ 安装MariaDB103，过程开始 ############${CEND}"
	Install_MariaDB103 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 安装MariaDB103，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}安装MariaDB103失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}安装MariaDB103成功！${CEND}"
			echo ""
		fi        
    instsoft_menu
    ;;
    x|X)
    clear
    echo -e "\033[32m---------返回上一级目录------->\033[0m"
    system_menu
    ;;
    Q|q)
    echo -e "$CGREEN--------退出--------- $CEND"
    exit 0
    ;;
    "")
    ;; #如果什么都不输入，什么都不做，也不报错
    *)
    echo -e "请输入正确编号"
    instsoft_menu
esac
done
}
#三级菜单
function xnk_menu()
{
cat<<EOF
${CMSG}============ 虚拟卡环境安装 ============${CEND}
`echo -e " [1]    2.1.1一键安装nginx和keepalived"`
`echo -e " [2]    2.1.2启动nginx和keepalived服务"`
`echo -e " [3]    2.1.3停止nginx和keepalived服务"`
`echo -e " [4]    2.1.4卸载nginx和keepalived"`
`echo -e " [5]    2.1.5查看日志"`
`echo -e " [x]    返回主菜单"`tail -f /var/log/messages
`echo -e " [q]    退出"`
${CMSG}============ 请选择操作的选项 ============${CEND}
EOF
while :;do
read -p "请输入编号:" num4
case $num4 in
    1)
    clear
    echo "${CMSG}############ 一键安装nginx和keepalived、配置、启动，过程开始 ############${CEND}"
	install_keepalived 2>&1 | tee -a ${logfile}
	#install_nginx 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 一键安装nginx和keepalived、配置、启动，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}一键安装nginx和keepalived、配置、启动失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}一键安装nginx和keepalived、配置、启动成功！${CEND}"
			echo ""
		fi
    xnk_menu
    ;;
    2)
    clear
    echo "${CMSG}############ 启动nginx和keepalived服务，过程开始 ############${CEND}"
	start_keepalived 2>&1 | tee -a ${logfile}
	#start_nginx 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 启动nginx和keepalived服务，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}启动nginx和keepalived服务失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}启动nginx和keepalived服务成功！${CEND}"
			echo ""
		fi
    xnk_menu
    ;;
    3)
    clear
    echo "${CMSG}############ 停止nginx和keepalived服务，过程开始 ############${CEND}"
	stop_keepalived 2>&1 | tee -a ${logfile}
	#stop_nginx 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 停止nginx和keepalived服务，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}停止nginx和keepalived服务失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}停止nginx和keepalived服务成功！${CEND}"
			echo ""
		fi
    xnk_menu
    ;;
    4)
    clear
    echo "${CMSG}############ 卸载nginx和keepalived服务，过程开始 ############${CEND}"
	#systemctl stop tomcat.service 2>&1 | tee -a ${logfile}
    echo "${CMSG}############ 卸载nginx和keepalived服务，过程结束 ############${CEND}"
		if [ $? != 0 ]; then
			echo "-- ${CFAILURE}卸载nginx和keepalived服务失败${CEND}"
			echo ""
		else
			echo "-- ${CMSG}卸载nginx和keepalived服务成功！${CEND}"
			echo ""
		fi
    xnk_menu
    ;;
    5)
    clear
    echo "${CMSG}############ 日志信息 ############${CEND}"
	#systemctl stop tomcat.service 2>&1 | tee -a ${logfile}
    #tail -f /var/log/messages
    cat /var/log/messages
    echo "${CMSG}############ 日志信息 ############${CEND}"
    xnk_menu
    ;;
    x|X)
    clear
    echo -e "\033[32m---------返回上一级目录------->\033[0m"
    server_menu
    ;;
    Q|q)
    echo -e "$CGREEN--------退出--------- $CEND"
    exit 0
    ;;
    "")
    ;; #如果什么都不输入，什么都不做，也不报错
    *)
    echo -e "请输入正确编号"
    xnk_menu
esac
done
}
#三级菜单
function wlw_menu()
{
cat<<EOF
${CMSG}============ 物联网环境安装 ============${CEND}
`echo -e " [1]    2.2.1一键安装docker和物联网"`
`echo -e " [2]    2.2.2配置"`
`echo -e " [3]    2.2.3服务启动停止"`
`echo -e " [4]    2.2.4卸载"`
`echo -e " [x]    返回主菜单"`
`echo -e " [q]    退出"`
${CMSG}============ 请选择操作的选项 ============${CEND}
EOF
while :;do
read -p "请输入编号:" num4
case $num4 in
    1)
    clear
    `echo -e "systemctl start nginx.service"`
    wlw_menu
    ;;
    2)
    clear
    `echo -e "systemctl start httpd.service"`
    wlw_menu
    ;;
    3)
    clear
    `echo -e "systemctl start tomcat.service"`
    wlw_menu
    ;;
    x|X)
    clear
    echo -e "\033[32m---------返回上一级目录------->\033[0m"
    server_menu
    ;;
    Q|q)
    echo -e "$CGREEN--------退出--------- $CEND"
    exit 0
    ;;
    "")
    ;; #如果什么都不输入，什么都不做，也不报错
    *)
    echo -e "请输入正确编号"
    wlw_menu
esac
done
}
#三级菜单
function op_menu()
{
cat<<EOF
------------------------
1）开启nginx服务
2）开启http服务
3）开启tomcat服务
X）返回上一级目录
------------------------
EOF
while :;do
read -p "请输入编号:" num4
case $num4 in
    1)
    clear
    `echo -e "systemctl start nginx.service"`
    op_menu
    ;;
    2)
    clear
    `echo -e "systemctl start httpd.service"`
    op_menu
    ;;
    3)
    clear
    `echo -e "systemctl start tomcat.service"`
    op_menu
    ;;
    x|X)
    clear
    echo -e "\033[32m---------返回上一级目录------->\033[0m"
    op_menu
    ;;
    Q|q)
    echo -e "$CGREEN--------退出--------- $CEND"
    exit 0
    ;;
    "")
    ;; #如果什么都不输入，什么都不做，也不报错
    *)
    echo -e "请输入正确编号"
    op_menu
esac
done
}
#三级菜单
function op_menu1()
{
cat<<EOF
------------------------
1）停止nginx服务
2）停止http服务
3）停止tomcat服务
X）返回上一级目录
------------------------
EOF
while :;do
read -p "请输入编号:" num5
case $num5 in
    1)
    clear
    `echo -e "systemctl stop nginx.service"`
    op_menu1
    ;;
    2)
    clear
    `echo -e "systemctl stop httpd.service"`
    op_menu1
    ;;
    3)
    clear
    `echo -e "systemctl stop tomcat.service"`
    op_menu1
    ;;
    x|X)
    clear
    echo -e "\033[32m---------返回上一级目录------->\033[0m"
    op_menu
    ;;
    Q|q)
    echo -e "$CGREEN--------退出--------- $CEND"
    exit 0
    ;;
    "")
    ;; #如果什么都不输入，什么都不做，也不报错
    *)
    echo -e "请输入正确编号"
    op_menu1
esac
done
}
menu